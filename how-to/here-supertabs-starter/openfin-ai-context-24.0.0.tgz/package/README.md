# @openfin/ai-context

Library for receiving and parsing DOM content from a given set of Views.

## Details

## Main APIs
Usage:
```ts
const { getContext, fireContextChanged } = await useAIContext({ fin, logger });
```

- `getContext` -> returns the results of all the parsed DOM contexts.
- `onSetActivPage` -> a hook to call that pushes a ContextChangedEvent to a set registered listeners.

### DOM-Contexts and Resolvers

The dom-contexts are mapped by `ContextProviderType` for each supported resolver.

Currently supported resolvers:
- html -> raw HTML via document.body.outerHTML string
- readability -> parsed by [mozilla readability](https://js.langchain.com/docs/integrations/document_transformers/mozilla_readability/)
    - We leverage the helper `isProbablyReaderable` before parsing and if this returns false, the results indicate the data was not reader friendly.
- screenshots -> leverages fin.WebContents.capturePage defaulting to 'png' format.

The raw DOM data is only retrieved on-demand, there is no caching or pushing involved, but this could be a future enhancement.

## Constraints

- The notable reponse type `AIContextResponse` includes each resolver as an optional key to ensure backwards compatibility as we add more resolvers and clients have not yet updated their preload scripts.
- The entry point `useAIContext` will create a single ChannelProvider which the preload scripts connect to. 
- This package expects the consumer to be a Platform Provider window in order for there to be a single ChannelProvider.
- This package is unaware of any HERE EB security tooling/constraints, it expects that the caller has already filtered all the view identities by domain rules or admin settings, etc.

## Assets

Preload scripts are under the `src/assets/` folder. This package outputs 2 preload scripts
- `dom-sender.cjs` -> used by content views to enable sending raw DOM data to the ChannelProvider
- `ai-context.cjs` -> a thin entry point meant to hide `fin` usage from the caller, which dispatches to the Platform Provider's `getAIContext` override which invokes the main APIs.
