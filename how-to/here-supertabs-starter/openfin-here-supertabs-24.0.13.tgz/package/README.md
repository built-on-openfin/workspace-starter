# @openfin/here-supertabs

Here Supertabs is an experimental mechanism to use Enterprise Browser style windows in Workspace.

Here Supertabs takes care of configuring the browser when used, offering a smaller set of options for configuration.

> **Experimental** — this package is subject to breaking changes without notice.

## Installation

```bash
npm i @openfin/here-supertabs
```

## Prerequisites

Here-supertabs is a self hosted distribution. In the `out/browser` folder, the Enterprise UI assets are provided.

It is up to you to host these assets in your CDN. Please note the following constraints apply:

-   The Enterprise UI assets must be on the same origin / storage provider as your provider.
-   Currently, only the `platform` basepath is supported (`<origin>/platform/enterprise`), meaning that all files in the `out/browser` folder should be placed in `/platform/enterprise`.

## Usage

`defineConfig` is used to configure your here-supertabs browser experience. It returns an object with a `getConfig()` accessor and an `experimental.toWorkspace()` adapter that replaces the standard `@openfin/workspace-platform` initialisation.

```typescript
import { defineConfig } from '@openfin/here-supertabs';

const supertabs = defineConfig({
    build: {
        // Absolute base URL where the Here Supertabs browser assets are hosted. Currently only <origin>/platform/enterprise is supported.
        baseUrl: 'https://my-cdn.example.com/platform/enterprise',
        // URL loaded when the user opens a new tab or page
        landingPageUrl: 'https://my-cdn.example.com/new-tab'
    }
});

const { init, getCurrentSync } = supertabs.experimental.toWorkspace();

// Initialise the workspace platform — same shape as @openfin/workspace-platform init,
// but `browser` and `workspaceAsar` are no longer configurable.
await init({
    theme: [
        {
            label: 'Default',
            palettes: {
                light: { brandPrimary: '#0A76D3' },
                dark: { brandPrimary: '#0A76D3' }
            }
        }
    ],
    customActions: {
        // your custom platform actions
    },
    overrideCallback: async (WorkspacePlatformProvider) => {
        // optional: extend the platform provider as normal
        return new WorkspacePlatformProvider();
    }
});

// After init, use getCurrentSync() exactly as you would from @openfin/workspace-platform
const platform = getCurrentSync();
await platform.Browser.createWindow({
    workspacePlatform: {
        pages: []
    }
});
```

## Notes

-   Address bar and bookmarks are **disabled** by default in Here Supertabs windows. These features are not yet supported through this API and will become configurable in a future release.
-   `build.baseUrl` must be an absolute URL pointing to your hosted `platform/enterprise` assets (no trailing slash).
-   `build.landingPageUrl` must be a non-empty string; it is stored in `localStorage` and picked up by the enterprise browser to determine the new-tab URL.
