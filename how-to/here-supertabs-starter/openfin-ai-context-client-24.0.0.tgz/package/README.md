# @openfin/ai-context-client

A client for interacting with the AI-Context features of the platform.

## Usage

This library should be consumed by Chat Companion Views only.

The underlying `window._aiContext` object is injected in a View when the `Use AI Context` Admin Panel Content setting is turned ON.

This library is a thin wrapper around the `window._aiContext` object to expose typed functions to the caller so they don't have to use `window.` nor have to find hacks to type the window prop. In this way we also ensure future upgrades are simpler to consume by users and keep ourselves open for changing the implementation under the hood if we need to.
